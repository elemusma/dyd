<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, inital-scale=1">
<title></title>
<?php wp_head(); ?>
<meta name="description" content="">
<meta name="keywords" content="Human Behavior, Communication, ">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
  <!-- main-header -->
  <div class="main-header">


  		<div class="container-fluid menu-nav">
        <div class="container">
  				<div class="logo"> <a href="<?php echo get_site_url(); ?>"><img src="http://localhost:8888/dyd/wp-content/uploads/2018/11/Drive-Your-Development-Logo-dark-skin-uai-516x291.png" class="logo-img" alt=""></a> </div>
  				<!-- logo -->

  				<!-- menu-trigger -->
  		<a class="header-menu-toggle navbar-toggle"  data-toggle="collapse" data-target="#myNavbar"> <span class="header-menu-icon"></span> </a>
  				<!-- menu-trigger -->



  			  <div class="navbar-header">
  	<a class="header-menu-toggle navbar-toggle"  data-toggle="collapse" data-target="#myNavbar"> <span class="header-menu-icon"></span> </a>

      </div>

  			 <div class="collapse navbar-collapse" id="myNavbar"><div class="menu">
           <?php wp_nav_menu('MainMenuLocation'); ?>
  				<!-- <ul class="list-inline pull-right">
  					<li><a href="index.html">Home</a></li>
  					<li><a href="services.html">Services</a></li>
  					<li><a href="about.html">About</a></li>
  					<li><a href="portfolio.html">Portfolio</a></li>
  					<li><a href="contact.html">Contact</a></li>
  			</ul> -->
  			</div>

  </div>

  		</div>
      </div>
  		<!-- container-fluid -->

  		<div class="container">
  				<div class="col-md-6 col-xs-12 col-sm-12 pull-left">
  						<?php the_post_thumbnail(); ?>
  						<!-- header-caption -->
  				</div>
          <div class="col-md-6 col-xs-12 col-sm-12 pull-right style-light">
  						<div class="header-caption">
  								<h4><?php the_field('overheading'); ?></h4>
  								<h1 class="sr-page-title"><?php the_title(); ?></h1>
  								<p><?php the_field('description'); ?></p>
  								<a href="portfolio.html" class="btn">Our Portfolio </a> </div>
  						<!-- header-caption -->
  				</div>
  		</div>
  		<!-- container -->

  </div>
  <!-- main-header -->
