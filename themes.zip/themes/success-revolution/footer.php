<footer>
		<p>© 2018 <span>Kliky</span>. All rights reserved. Theme by <span>PmassIndia</span></p>
		<ul class="list-inline social">
				<li> <a href="#"> <img src="assets/images/facebook.png" alt=""> </a></li>
				<li> <a href="#"> <img src="assets/images/twitter.png" alt=""> </a></li>
				<li> <a href="#"> <img src="assets/images/instagram.png" alt=""> </a></li>
		</ul>
</footer>
<?php wp_footer(); ?>
</body>
</html>
