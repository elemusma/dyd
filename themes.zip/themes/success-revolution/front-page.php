<?php get_header(); ?>

<section class="services " id="section1">
<div class="container">
<!--<div class="col-md-6 col-xs-12 col-sm-12 no-padding ser-img ">

	</div>-->

	<div class="col-md-4 col-xs-12 col-sm-12 ser-box bg-2 style-dark">
	<div class="ser-in">
	<div class="icon">
		<img src="assets/images/camera.png" class="icon-img" alt="">
		</div>
		<h4>Black & White Photography</h4>
		<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form by their team.</p>
		<a href="services.html">Read more </a>
		</div>
	</div>

	<!-- ser-box -->


		<div class="col-md-4 col-xs-12 col-sm-12 ser-box bg-3 style-dark">
		<div class="ser-in">
	<div class="icon">
		<img src="assets/images/photograph.png" class="icon-img" alt="">
		</div>
		<h4>Fashion Photography</h4>
		<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form by their team.</p>
		<a href="services.html">Read more </a>
			</div>
	</div>

	<!-- ser-box -->


		<div class="col-md-4 col-xs-12 col-sm-12 ser-box style-dark">
		<div class="ser-in">
	<div class="icon">
		<img src="assets/images/ad-photo.png" class="icon-img" alt="">
		</div>
		<h4>Advertorial Photography</h4>
		<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form by their team.</p>
		<a href="services.html">Read more </a>
			</div>
	</div>

	<!-- ser-box -->
</div>
	</section>



<div class="section" id="section2">
		<div class="container">
				<div class="heading col-md-12 col-xs-12">
				 <h2>About Us </h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed</p>
						<h4 class="light hidden-xs"> Photography</h4>
				</div>
				<!-- heading -->
				<div class="clearfix"></div>
				<div class="about-inner">
						<div class="images col-md-5 col-xs-12 col-sm-12"> <img src="assets/images/home_07.png" class="img-responsive img-1" alt=""  > <img src="assets/images/home_05.png" class="img-responsive img-2" alt="" > </div>
						<!-- images -->

						<div class="col-md-5 col-xs-12 col-sm-12 about-content col-md-offset-1">

								<p>We Believe that Interior
									beautifies the Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Maecenas sed diam eget risus varius blandit sit amet non magna. Aenean lacinia bibendum nulla sed consectetur. Vestibulum id ligula porta felis euismod semper.</p>
								<p class="ptb-30 span ">“Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Nullam id dolor id nibh ultricies vehicula ut id elit. Cum sociis natoque penatibus.”</p>
								<a href="about.html" class="btn btn-yellow">Read more </a> </div>
				</div>
				<!-- about inner -->
		</div>
		<!-- container -->

</div>
<!-- section-about -->




<div class="section advertorial" id="section3">
		<div class="container">
				<div class="heading col-md-6 col-xs-12"> <h2>Portfolio</h2>
						<p>I take photographs with creativity, concept and passion</p>
				</div>
				<!-- heading -->
		</div>
		<div class="swiper-container fashion-container" >
				<div class="swiper-wrapper">
						<div class="swiper-slide"> <a data-fancybox="gallery" href="assets/images/adv1.jpg"> <img src="assets/images/adv1.jpg" class="img-responsive" alt=""> </a> </div>
						<!-- swiper-slide -->

						<div class="swiper-slide"> <a data-fancybox="gallery" href="assets/images/adv2.jpg"> <img src="assets/images/adv2.jpg" class="img-responsive" alt=""> </a> </div>
						<!-- swiper-slide -->

						<div class="swiper-slide"> <a data-fancybox="gallery" href="assets/images/adv3.jpg"> <img src="assets/images/adv3.jpg" class="img-responsive" alt=""> </a> </div>
						<!-- swiper-slide -->

						<div class="swiper-slide"> <a data-fancybox="gallery" href="assets/images/adv4.jpg"> <img src="assets/images/adv4.jpg" class="img-responsive" alt=""> </a> </div>
						<!-- swiper-slide -->

						<div class="swiper-slide"> <a data-fancybox="gallery" href="assets/images/adv5.jpg"> <img src="assets/images/adv5.jpg" class="img-responsive" alt=""> </a> </div>
						<!-- swiper-slide -->

						<div class="swiper-slide"> <a data-fancybox="gallery" href="assets/images/adv6.jpg"> <img src="assets/images/adv6.jpg" class="img-responsive" alt=""> </a> </div>
						<!-- swiper-slide -->

						<div class="swiper-slide"> <a data-fancybox="gallery" href="assets/images/adv7.jpg"> <img src="assets/images/adv7.jpg" class="img-responsive" alt=""> </a> </div>
						<!-- swiper-slide -->

						<div class="swiper-slide"> <a data-fancybox="gallery" href="assets/images/adv8.jpg"> <img src="assets/images/adv8.jpg" class="img-responsive" alt=""> </a> </div>
						<!-- swiper-slide -->

				</div>

				<!-- Add Arrows -->
				<div class="swiper-button-next"></div>
				<div class="swiper-button-prev"></div>
		</div>
</div>
<!-- portfolio -->


<div class="section" id="section4">

	<div class="container">


		<div class="heading col-md-6 col-xs-12"> <h2>Contact us</h2>
						<p>We'd love to hear from you!</p>
				</div>
				<!-- heading -->
	<div class="row input-container">
	<form>
			<div class="col-xs-12">
				<div class="styled-input wide">
					<input type="text" required />
					<label>Name</label>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<div class="styled-input">
					<input type="text" required />
					<label>Email</label>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<div class="styled-input" style="float:right;">
					<input type="text" required />
					<label>Phone Number</label>
				</div>
			</div>
			<div class="col-xs-12">
				<div class="styled-input wide">
					<textarea required></textarea>
					<label>Message</label>
				</div>
			</div>
			<div class="col-xs-12">
				<input class="btn btn-yellow" type="submit" value="Send Message">
			</div>
			</form>
	</div>

</div>

</div>


<div class=" section client-post " >
		<div class="container">
				<div class="heading col-md-6 col-xs-12"> <h2>Our Partner </h2>
						<p>Praesent commodo cursus magna</p>
				</div>
				<div class="clearfix"></div>

				<!-- heading -->

				<div class="post">
						<div class="col-md-2 col-xs-4 col-sm-4 in-post">
							<img src="assets/images/partner01.png" class="img-responsive insta-photo" alt="">
						</div>

						<div class="col-md-2 col-xs-4 col-sm-4 in-post">
							<img src="assets/images/partner02.png" class="img-responsive insta-photo" alt="">
						</div>

						<div class="col-md-2 col-xs-4 col-sm-4 in-post">
							<img src="assets/images/partner03.png" class="img-responsive insta-photo" alt="">
						</div>


						<div class="col-md-2 col-xs-4 col-sm-4 in-post">
							<img src="assets/images/partner04.png" class="img-responsive insta-photo" alt="">
						</div>
							<div class="col-md-2 col-xs-4 col-sm-4 in-post">
							<img src="assets/images/partner05.png" class="img-responsive insta-photo" alt="">
						</div>

						<div class="col-md-2 col-xs-4 col-sm-4 in-post">
							<img src="assets/images/partner01.png" class="img-responsive insta-photo" alt="">
						</div>



				</div>
		</div>
</div>

<!-- Partner -->

<?php get_footer(); ?>
